#!/bin/bash
sudo chown root legado1
sudo chmod 7777 legado1
