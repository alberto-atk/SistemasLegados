------------------- EJECUCIÓN -------------------
Para ejecutar Wrapper.jar hace falta ejecutar con Java 11.0.14.

Se ejecuta desde línea de comando con "java -jar Wrapper.jar".

------------------- FEEDBACK y ERRORES -------------------
El programa proporciona el feedback necesario en los casos de error más comunes.

En el caso de que hayan transcurrido más de 10 segundos al iniciar sesión, 
puede que la máquina no esté respondiendo. Es un problema que ocurre de forma 
aleatoria y tiene que ver con Forticlient VPN. Reiniciando Forticlient se puede
arreglar el problema.

PEOR CASO -> si no se consigue la conexión con la máquina 155.210.71.101:123, se
puede probar con la máquina 155.210.71.101:723 que no requiere conexión a través 
de Forticlient.